import { createContext } from "react";

let BalanceContext = createContext(23) // default value of balance context


export default BalanceContext;