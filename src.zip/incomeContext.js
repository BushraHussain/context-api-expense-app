import { createContext } from "react";


let IncomeContext = createContext(1000); // suppose total income = 1000

export default  IncomeContext;