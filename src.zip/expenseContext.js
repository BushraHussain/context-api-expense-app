import { createContext } from "react";


let ExpenseContext = createContext(300); // suppose total expense = 500

export default ExpenseContext;